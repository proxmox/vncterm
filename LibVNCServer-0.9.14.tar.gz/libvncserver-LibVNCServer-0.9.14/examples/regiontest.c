#define SRA_TEST
#include "../libvncserver/rfbregion.c"

